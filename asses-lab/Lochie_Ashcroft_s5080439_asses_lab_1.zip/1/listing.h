void get_cur_files();
