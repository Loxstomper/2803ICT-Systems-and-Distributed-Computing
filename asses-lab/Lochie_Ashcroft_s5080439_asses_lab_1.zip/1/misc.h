
void get_path();
int prefix(int *curr_index, int last_index, char *argv[]);
