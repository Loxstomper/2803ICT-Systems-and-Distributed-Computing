#ifndef DUMP_H
#define DUMP_H

void get_dump(char* path);


#endif
