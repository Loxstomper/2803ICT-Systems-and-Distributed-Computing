i686-w64-mingw32-gcc -o shell listing.c dump.c misc.c calc.c main.c
